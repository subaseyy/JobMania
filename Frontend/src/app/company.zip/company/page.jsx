import DashboardLayout from "./layout";

export default function page({ children }) {
  return <DashboardLayout>{children}</DashboardLayout>;
}
